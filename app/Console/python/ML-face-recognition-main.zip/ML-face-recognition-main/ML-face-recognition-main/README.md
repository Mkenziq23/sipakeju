﻿# Machine Learning face-recognition 📷
 ![Foto](https://user-images.githubusercontent.com/48589121/200715958-b3988afd-fa22-40e9-8c9e-3b60cff442a9.png)

Face recognition dengan dataset yang telah tersedia.
### 📸 Untuk menjalankannya
Install module opencv untuk dapat menjalankan program ***pip install opencv-python***
> run rekam.py
📸 Setelah itu akan memulai perekaman wajah dan silahkan masukan Id
** Semua data rekaman akan tersimpan di folder ***/dataset***
> run training.py
📸 Untuk membuat dan menyimpan data training hasil rekaman
> run scan.py
untuk melihat hasil
