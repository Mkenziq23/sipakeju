# tfjs-faceapi

Script ini digunakan untuk proses pengunaan FACE-API.JS pada video youtube berikut : https://youtu.be/T_MuDMZk8D4



## Penjelasan 

```bash
Tensorflow.js merupakan Open Source Machine learning library milik Google, dengan Tensorflow kita dapat memanfaatkan model2 yang telah dibentuk dan dibuat dengan Tensorflow versi Pyhton untuk dapat kita gunakan pada Web browser.

FACE-API.JS
Sebuah javascript library yang dikembangkan mengunakan Tensorflow.js core untuk membantu melakukan Pengenalan Wajah, Face landmark, Deteksi Ekspresi wajah, serta deteksi jenis kelamin dan juga estimasi umur 

```
